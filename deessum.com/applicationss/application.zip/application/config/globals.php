<?php
$config['project_head']= 'HASDEO';
$config['project_name']= 'HASDEO Shopping';
$config['icon']= 'CodeIgniter Global Variable';
$config['favicon']= 'CodeIgniter Global Variable';