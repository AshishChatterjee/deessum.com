<link rel="stylesheet" href="<?php echo base_url('assets/plugins/summernote/dist/summernote-lite.css'); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/plugins/summernote/dist/plugin/codemirror/codemirror.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/plugins/summernote/dist/plugin/codemirror/themes/monokai.css'); ?>">
<script type="text/javascript" src="<?php echo base_url('assets/plugins/summernote/dist/plugin/codemirror/codemirror.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/plugins/summernote/dist/plugin/codemirror/xml.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/plugins/summernote/dist/plugin/codemirror/formatting.js'); ?>"></script>

<style>
    .note-editor.note-frame{
        border:none;
    }
    .note-frame.card{
        margin-bottom:0px;
    }
</style>