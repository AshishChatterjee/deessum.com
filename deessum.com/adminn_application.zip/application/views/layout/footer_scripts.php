<!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/popper.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>

<!-- simplebar js -->
    <script src="<?php echo base_url('assets/plugins/simplebar/js/simplebar.js'); ?>"></script>
<!-- waves effect js -->
    <script src="<?php echo base_url('assets/js/waves.js'); ?>"></script>
<!-- sidebar-menu js -->
    <script src="<?php echo base_url('assets/js/sidebar-menu.js'); ?>"></script>
<!-- Custom scripts -->
    <script src="<?php echo base_url('assets/js/app-script.js'); ?>"></script>

<!-- Sparkline JS -->
    <script src="<?php echo base_url('assets/plugins/sparkline-charts/jquery.sparkline.min.js'); ?>"></script>
<!-- Chart js -->
    <script src="<?php echo base_url('assets/plugins/Chart.js/Chart.min.js'); ?>"></script>
<!--Morris JavaScript -->
    <!-- <script src="<?php echo base_url('assets/plugins/raphael/raphael-min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/plugins/morris/js/morris.js'); ?>"></script> -->
<!-- Sweet Alert -->
    <script src="<?php echo base_url('assets/plugins/alerts-boxes/js/sweetalert.min.js'); ?>"></script>
<!-- For Notifications -->
    <script src="<?php echo base_url("assets/js/bootstrap-notify/bootstrap-notify.js"); ?> "></script>
    <script src="<?php echo base_url("assets/js/notie/notie.js"); ?> "></script>
<!-- Common Utilities like load, isnumber, ischarector etc -->
    <script src="<?php echo base_url("assets/js/common_utilities.js"); ?> "></script>

<!--Select Plugins Js-->
    <script src="<?php echo base_url('assets/plugins/select2/js/select2.min.js'); ?>"></script>
<!--Inputtags Js-->
    <script src="<?php echo base_url('assets/plugins/inputtags/js/bootstrap-tagsinput.js'); ?>"></script>
    <script src="<?php echo base_url('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js'); ?>"></script>