<!-- Vector CSS -->
<link href="<?php echo base_url('assets/plugins/vectormap/jquery-jvectormap-2.0.2.css'); ?> " rel="stylesheet" />
<!-- simplebar CSS-->
<link href="<?php echo base_url('assets/plugins/simplebar/css/simplebar.css'); ?> " rel="stylesheet" />
<!-- Bootstrap core CSS-->
<link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?> " rel="stylesheet" />
<!-- animate CSS-->
<link href="<?php echo base_url('assets/css/animate.css'); ?> " rel="stylesheet" type="text/css" />
<!-- Icons CSS-->
<link href="<?php echo base_url('assets/css/icons.css'); ?> " rel="stylesheet" type="text/css" />
<!-- Font Awsome CSS-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Sidebar CSS-->
<link href="<?php echo base_url('assets/css/sidebar-menu.css'); ?> " rel="stylesheet" />
<!-- Custom Style-->
<link href="<?php echo base_url('assets/css/app-style.css'); ?> " rel="stylesheet" />
<!--Data Tables -->
<link href="<?php echo base_url('assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css'); ?> " rel="stylesheet" type="text/css">
<link href="<?php echo base_url('assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css'); ?> " rel="stylesheet" type="text/css">
<!-- Select Plgin -->
<link href="<?php echo base_url('assets/plugins/select2/css/select2.min.css'); ?>" rel="stylesheet" />
<!--multi select-->
<link href="<?php echo base_url('assets/plugins/jquery-multi-select/multi-select.css'); ?>" rel="stylesheet" type="text/css">
<!--Bootstrap Datepicker-->
<link href="<?php echo base_url('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css'); ?>" rel="stylesheet" type="text/css">