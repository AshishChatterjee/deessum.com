<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Question profile - <?php echo $project_head; ?></title>
    <!--favicon-->
    <link rel="icon" href="<?php echo base_url('assets/logo/favicon.png'); ?> " type="image/x-icon">
    <?php include 'layout/header_links.php'; ?>
    <?php include 'layout/link_and_script_of_summernote.php'; ?>
</head>

<body>

    <!-- Start wrapper-->
    <div id="wrapper">
        <!--Start sidebar-wrapper-->
            <?php include 'layout/left_side_navigation.php' ?>
        <!--Start sidebar-wrapper-->

        <!--Start topbar header-->
            <?php include 'layout/header.php'; ?>
        <!--End topbar header-->

        <div class="clearfix"></div>

        <!--Start content-wrapper-->
            <div class="content-wrapper" >
                <div class="container-fluid" style="min-height:500px;" >

                    <!-- Breadcrumb-->
                    <div class="row pt-2 pb-2">
                        <div class="col-sm">
                            <h4 class="page-title">Question</h4>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javaScript:void();">Question</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Profile</li>
                            </ol>
                        </div>
                        <div class="col-sm-2">
                            <div class="float-sm-right">
                                <a href="<?php echo base_url('question/questionList'); ?>" >
                                    <button class="btn-outline-success border-0 shadow-light m-1"> <span class="moon-security-on"></span> Question List</button>
                                </a>
                                <a href="<?php echo base_url('question/question/'.$question->id."/EDiT"); ?>" >
                                    <button class="btn-outline-warning border-0 shadow-light m-1"> <span class="moon-security-on"></span> Edit</button>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- End Breadcrumb-->

                    <!-- Form Row Start Here -->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <?php echo $question->round; ?>
                                    <br/>
                                    Question Profile 
                                    <?php if(!$question->active){ ?>
                                        <a href="<?php echo base_url("question/activateQuestion/".$question->id); ?>"><button class="btn btn-outline-success btn-sm pull-right">ACTIVATE</button></a>
                                    <?php }else{ ?>
                                        <a href="<?php echo base_url("question/deactivateQuestion/".$question->id); ?>"><button class="btn btn-outline-danger btn-sm pull-right">DEACTIVATE</button></a>
                                    <?php } ?>
                                </div>
                                <div class="card-body">
                                    <p>
                                        <strong>Question : </strong><?php echo $question->question; ?>
                                    </p>

                                    <hr/>
                                    <?php if(!$question->o_active){ ?>
                                        <a href="<?php echo base_url("question/showAnswerOption/".$question->id); ?>"><button class="btn btn-outline-success btn-sm pull-right">SHOW</button></a>
                                    <?php } ?>
                                    <p>
                                        <strong>Option 1 : </strong><?php echo $question->option1; ?>
                                    </p>
                                    <p>
                                        <strong>Option 2 : </strong><?php echo $question->option2; ?>
                                    </p>
                                    <p>
                                        <strong>Option 3 : </strong><?php echo $question->option3; ?>
                                    </p>
                                    <p>
                                        <strong>Option 4 : </strong><?php echo $question->option4; ?>
                                    </p>
                                    <hr/>

                                    <p>
                                        <strong>Ans : </strong><?php echo $question->ans; ?>
                                    </p>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Form Row End Here -->

                </div>
                <!-- End container-fluid-->
            </div>
        <!--End content-wrapper-->

        <!--Start Back To Top Button-->
            <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
        <!--End Back To Top Button-->

        <!--Start footer-->
        <?php include 'layout/footer.php'; ?>
        <!--End footer-->

    </div>
    <!--End wrapper-->
    <?php include 'layout/footer_scripts.php'; ?>
    <script src="<?php echo base_url('assets/plugins/summernote/dist/summernote-lite.js'); ?>"></script>
    <script>
        $('#reciving_date').datepicker({
            autoclose: true,
            todayHighlight: true,
            format: 'dd/mm/yyyy'
        });
        $('#description').summernote({
            height: 200,
            tabsize: 2,
            codemirror: { // codemirror options
                theme: 'monokai'
            }
        });
    </script>
</body>

</html>