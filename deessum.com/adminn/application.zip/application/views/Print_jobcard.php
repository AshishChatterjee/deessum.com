<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="<?php echo base_url('assets/custom_fonts/font_classes.css'); ?>">
    <style>
        .job-card-div {
            border: 1px solid black;
            width: 800px;
            padding: 10px;
        }
        table{
            width:100%;
        }
        table tr td{
            padding:3px;
        }
    </style>

    <style type="text/css" media="print">
        @page 
        {
            size: auto;   /* auto is the initial value */
            margin: 0mm;  /* this affects the margin in the printer settings */
        }
    </style>
</head>

<body id="body">
    <div class="job-card-div" id="printarea">
        
        <div style="width:100px; float:left;">
            <img style="width:100%;" src="<?php echo base_url("assets/logo/logo.jpg"); ?>" />
        </div>
        <div>
            <h1 class="" style="margin:0; text-align:center;">
                Hitech Computer Care Service
            </h1>
            <p class='old-standerd-font' style="margin:0;  text-align:center;">Near Agrawal Childrem Hospital, Magarparar Road, Bilaspur(C.G)</p>
        </div>
        <p class="clear:both;"></p>
        <hr style="border:1px solid gray;"/>
        <p style="margin:0; padding:0; text-align:right;">
            <?php echo substr($customer->call_log_date,8,2)."/".substr($customer->call_log_date,5,2)."/".substr($customer->call_log_date,0,4)." ".substr($customer->call_log_date,10); ?>
        </p>
        <h2 class="overpass-heavy-font" style="margin:0; text-align:center;">Job Sheet</h2>
        <br/>
        <table class="job-card-table">
            <tr>
                <td><strong>JOB NO. </strong></td>
                <td> : <strong><?php echo $customer->id; ?></strong></td>
            </tr>
            <tr>
                <td><strong>CUSTOMER </strong></td>
                <td> : <?php echo $customer->name; ?></td>
                <td><strong>SER. PLACE </strong></td>
                <td> : <?php echo $customer->service_place; ?></td>
            </tr>
            <tr>
                <td><strong>MOBILE NO </strong></td>
                <td> : <?php echo $customer->mobile; ?></td>
                <td><strong>WRNT. STATUS </strong></td>
                <td> : <?php echo $customer->warrantee_status? "ON WARRANTEE" : "WARRANTEE EXPIRED"; ?></td>
            </tr>
            <tr>
                <td><strong>PROD NAME </strong></td>
                <td> : <?php echo $customer->product_name; ?></td>
                <td><strong>DELIVERTY </strong></td>
                <td> : <?php echo substr($customer->delivery_date,8,2)."/".substr($customer->delivery_date,5,2)."/".substr($customer->delivery_date,0,4)." ".$customer->delivery_time; ?></td>
            </tr>
            <tr>
                <td style="vertical-align:top;"><strong>PROD PROBLEM </strong></td>
                <td colspan="3">: <?php echo $customer->problem; ?></td>
            </tr>
            <tr>
                <td style="width:150px;"><strong>APPROX AMT. </strong></td>
                <td>: <?php echo $customer->approx_amt; ?></td>
                <td><strong>ENGINEER </strong></td>
                <td>: <?php echo $customer->engineer_name; ?></td>
            </tr>
        </table>
        <p style="text-align:right; margin-top:80px; margin-right:50px;"> Signature </p>
        <p class="old-standerd-font" style="text-align:center;  border-top:1px solid gray; margin:0; padding-top:10px;"> Working HRS. 11:00 AM to 9:00 PM, Help Line no. 07752 418900 </p>
    </div>
    <br />
    <!-- <button onclick="printJobCard()" id="print-btn">Print</button> -->
    <script>
        var divElements = document.getElementById("body").innerHTML;
        //Get the HTML of whole page
        var oldPage = document.body.innerHTML;

        //Reset the page's HTML with div's HTML only
        document.body.innerHTML = 
            "<html><head><title></title></head><body>" + 
            divElements + "</body>";

        //Print Page
        // window.print();

        //Restore orignal HTML
        document.body.innerHTML = oldPage;
    </script>
</body>

</html>