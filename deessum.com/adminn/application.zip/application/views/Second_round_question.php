<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Second round question - <?php echo $project_head; ?></title>
    <!--favicon-->
    <link rel="icon" href="<?php echo base_url('assets/logo/favicon.png'); ?> " type="image/x-icon">
    <?php include 'layout/header_links.php'; ?>
    <!--Switchery-->
    <link href="<?php echo base_url('assets/plugins/bootstrap-switch/bootstrap-switch.min.css'); ?>" rel="stylesheet">
    <?php include 'layout/link_and_script_of_summernote.php'; ?>
    <link rel="stylesheet" href="<?php echo base_url('assets/slim_img_uploader/slim.min.css'); ?>">
</head>

<body>

    <!-- Start wrapper-->
    <div id="wrapper">
        <!--Start sidebar-wrapper-->
            <?php include 'layout/left_side_navigation.php' ?>
        <!--Start sidebar-wrapper-->

        <!--Start topbar header-->
            <?php include 'layout/header.php'; ?>
        <!--End topbar header-->

        <div class="clearfix"></div>

        <!--Start content-wrapper-->
            <div class="content-wrapper" >
                <div class="container-fluid" style="min-height:500px;" >

                    <!-- Breadcrumb-->
                    <div class="row pt-2 pb-2">
                        
                        <div class="col-sm-12">
                            <div class="">
                                <a href="<?php echo base_url('question/srq_list/'); ?>" >
                                    <button class="btn-outline-success border-0 shadow-light m-1 pull-right"> <span class="moon-security-on"></span> Question List</button>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- End Breadcrumb-->

                    <!-- Form Row Start Here -->
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card">
                                <div class="card-body bg-light-blue" >
                                    <div class="row pt-2 pb-2">
                                        <div class="col-sm">
                                            <h4>Second round question</h4>
                                        </div>
                                    </div>
                                    <hr/>
                                    <form method="post" id="service_form" action="<?php echo base_url('question/srq/') ?>">
                                        <input type="hidden" name="mode" id="mode" value="<?php if(isset($mode)){echo $mode; }else { echo set_value("mode"); } ?>" />
                                        <input type="hidden" name="id" id="id" value="<?php if(isset($question->id)){echo $question->id; }else { echo set_value("id"); } ?>" />

                                            <div class="row">

                                                <div class="col-md-12">
                                                    <div class="row">
                                                        <!-- Start : Question  -->
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label for="question">Question <span class="icon-star-empty text-danger"></span></label>
                                                                <input name="question" id="question" type="text" class="form-control" placeholder="Question" value="<?php if(isset($question->question)){echo $question->question; }else{echo set_value("question");} ?>">
                                                                <?php if(form_error("question")!=null){ echo form_error("question"); } ?>
                                                            </div>
                                                        </div>
                                                        <!-- End : Question -->
                                                    </div>
                                                </div>

                                                <div class="col-sm-12">
                                                    <button type="submit" class="btn btn-outline-success border-0 shadow-light m-1 pull-right"><span class="zmdi zmdi-check-all"></span> Submit</button>
                                                </div>
                                                <!-- End : Address -->
                                            </div>
                                        <br>
                                        <?php 
                                            $msg=$this->session->flashdata('message');
                                            if(isset($msg)){
                                                ?><br/><br/><p style="color:green;" class="pull-right"><?php echo $msg; ?></p><?php
                                            }
                                        ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Form Row End Here -->

                </div>
                <!-- End container-fluid-->
            </div>
        <!--End content-wrapper-->

        <!--Start Back To Top Button-->
            <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
        <!--End Back To Top Button-->

        <!--Start footer-->
        <?php include 'layout/footer.php'; ?>
        <!--End footer-->

    </div>
    <!--End wrapper-->
    <?php include 'layout/footer_scripts.php'; ?>
    <!--Bootstrap Switch Buttons-->
    <script src="<?php echo base_url('assets/plugins/bootstrap-switch/bootstrap-switch.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/plugins/summernote/dist/summernote-lite.js'); ?>"></script>
    <script src="<?php echo base_url('assets/slim_img_uploader/slim.kickstart.min.js'); ?>"></script>
    <script>
        $('#reciving_date').datepicker({
            autoclose: true,
            todayHighlight: true,
            format: 'dd/mm/yyyy'
        });
        $(document).ready(function() {
            $('.single-select').select2();

            $('.multiple-select').select2();
        });
        function submitForm() {
            $("#service_form").attr('action', "<?php echo base_url('services/getServicesOfSelectedCategory/');  ?>");
            $("#service_form").submit();
        }
        function deleteService(){
            alert("Deletion module is in waiting list");
            return false;
        }
        $(".bt-switch input[type='checkbox'], .bt-switch input[type='radio']").bootstrapSwitch();
        $('#description').summernote({
            height: 200,
            tabsize: 2,
            codemirror: { // codemirror options
                theme: 'monokai'
            }
        });

        function uploaded(error, data, response) {
            $('#uploaded_file_name').val(response['file']);
            $('#current_img_type').val("NEW");
            notie.alert(1, 'Image Uploaded Successfully!', 2);
        }

        $('#joining_date').datepicker({
            autoclose: true,
            todayHighlight: true,
            format: 'dd/mm/yyyy'
        });
    </script>
</body>

</html>