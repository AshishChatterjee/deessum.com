<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Temporary author - <?php echo $project_head; ?></title>
    <!--favicon-->
    <link rel="icon" href="<?php echo base_url('assets/logo/favicon.png'); ?> " type="image/x-icon">
    <?php include 'layout/header_links.php'; ?>
    <link href="<?php echo base_url('assets/plugins/bootstrap-switch/bootstrap-switch.min.css'); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url('assets/slim_img_uploader/slim.min.css'); ?>">
</head>

<body>

    <!-- Start wrapper-->
    <div id="wrapper">
        <!--Start sidebar-wrapper-->
            <?php include 'layout/left_side_navigation.php' ?>
        <!--Start sidebar-wrapper-->

        <!--Start topbar header-->
            <?php include 'layout/header.php'; ?>
        <!--End topbar header-->

        <div class="clearfix"></div>

        <!--Start content-wrapper-->
            <div class="content-wrapper" >
                <div class="container-fluid" style="min-height:500px;" >

                    <!-- Breadcrumb-->
                    <div class="row pt-2 pb-2">
                        <div class="col-sm">
                            <h4 class="page-title">Temporary author</h4>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javaScript:void();">Temporary author</a></li>
                                <li class="breadcrumb-item active" aria-current="page">New</li>
                            </ol>
                        </div>
                        <div class="col-sm-4">
                            <div class="float-sm-right">
                                <a href="<?php echo base_url('author/tmpAuthorList'); ?>" >
                                    <button class="btn-outline-success border-0 shadow-light m-1"> <span class="moon-security-on"></span> Temporary author List</button>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- End Breadcrumb-->

                    <!-- Form Row Start Here -->
                    <div class="row">
                        <div class="col-lg-8 ">
                            <div class="card">
                                <div class="card-body bg-light-blue">
                                    <div class="row pt-2 pb-2">
                                        <div class="col-sm">
                                            <h4>Temporary author</h4>
                                        </div>
                                    </div>
                                    <hr/>
                                    <form method="post" id="service_category_form" action="<?php echo base_url('author/tmpAuthor/') ?>">
                                        <input type="hidden" name="mode" id="mode" value="<?php if(isset($mode)){echo $mode; }else { echo set_value("mode"); } ?>" />
                                        <input type="hidden" name="id" id="id" value="<?php if(isset($author->id)){echo $author->id; }else { echo set_value("id"); } ?>" />

                                        
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="row">
                                                        <div class="col-sm-12">
                                                            <div class="row">
                                                                <!-- Start : Author name  -->
                                                                <div class="form-group col-sm-8">
                                                                    <label for="name">Name <span class="icon-star-empty text-danger"></span></label>
                                                                    <input name="name" id="name" type="text" class="form-control" placeholder="Services category name" value="<?php if(isset($author->name)){echo $author->name; }else{echo set_value("name");} ?>">
                                                                    <?php if(form_error("name")!=null){ echo form_error("name"); } ?>
                                                                </div>
                                                                <!-- End : Author name -->

                                                                <!-- Start : Mobile number  -->
                                                                <div class="form-group col-sm-4">
                                                                    <label for="mobile_no">Mobile number <span class="icon-star-empty text-danger"></span></label>
                                                                    <input name="mobile_no" id="mobile_no" type="text" class="form-control" placeholder="Mobile number" value="<?php if(isset($author->mobile_no)){echo $author->mobile_no; }else{echo set_value("mobile_no");} ?>">
                                                                    <?php if(form_error("mobile_no")!=null){ echo form_error("mobile_no"); } ?>
                                                                </div>
                                                                <!-- End : Mobile number -->

                                                                <!-- Start : Alternate Numbers  -->
                                                                <div class="form-group col-sm-8">
                                                                    <label for="alternate_nos">Alternate numbers <span class="icon-star-empty text-danger"></span></label>
                                                                    <input name="alternate_nos" id="alternate_nos" type="text" class="form-control" placeholder="Alternate number" value="<?php if(isset($author->alternate_nos)){echo $author->alternate_nos; }else{echo set_value("alternate_nos");} ?>">
                                                                    <?php if(form_error("alternate_nos")!=null){ echo form_error("alternate_nos"); } ?>
                                                                </div>
                                                                <!-- End : Alternate Numbers -->

                                                                <!-- Start : Email  -->
                                                                <div class="form-group col-sm-4">
                                                                    <label for="email">Email <span class="icon-star-empty text-danger"></span></label>
                                                                    <input name="email" id="email" type="text" class="form-control" placeholder="Email" value="<?php if(isset($author->email)){echo $author->email; }else{echo set_value("email");} ?>">
                                                                    <?php if(form_error("email")!=null){ echo form_error("email"); } ?>
                                                                </div>
                                                                <!-- End : Email -->

                                                                <!-- Start : Address  -->
                                                                <div class="form-group col-sm-9">
                                                                    <label for="address">Address <span class="icon-star-empty text-danger"></span></label>
                                                                    <input name="address" id="address" type="text" class="form-control" placeholder="Address" value="<?php if(isset($author->address)){echo $author->address; }else{echo set_value("address");} ?>">
                                                                    <?php if(form_error("address")!=null){ echo form_error("address"); } ?>
                                                                </div>
                                                                <!-- End : Address -->

                                                                <!-- Start : Next date -->
                                                                <div class="form-group col-sm-3">
                                                                    <label for="next_date">Next Date<span class="icon-star-empty text-danger"></span></label>
                                                                    <?php $next_date=set_value("next_date"); ?>
                                                                    <input type="text" name="next_date" id="next_date" class="form-control" value="<?php if(isset($author->next_date)){echo substr($author->next_date,8,2)."/".substr($author->next_date,5,2)."/".substr($author->next_date,0,4); }else{ if(isset($next_date) && $next_date!=""){ echo $next_date; }else{ echo date('d/m/Y'); }} ?>" >
                                                                    <?php if(form_error("profit_per")!=null){ echo form_error("profit_per"); } ?>
                                                                </div>                                         
                                                                <!-- End : Next date -->
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>

                                        </div>    

                                        <div class="form-group row pull-right">
                                            <div class="col-sm-10">
                                                <button type="submit" class="btn btn-outline-success border-0 shadow-light m-1"><span class="zmdi zmdi-check-all"></span> Submit</button>
                                            </div>
                                        </div>
                                        <br>
                                        <?php 
                                            $msg=$this->session->flashdata('message');
                                            if(isset($msg)){
                                                ?><br/><br/><p style="color:green;" class="pull-right"><?php echo $msg; ?></p><?php
                                            }
                                        ?>
                                    </form>
                                    
                                </div>
                            </div>
                        </div> 

                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h4>INSTRUCTIONS</h4>
                                </div>
                                <div class="card-body">
                                    <p>
                                        Hello here we will put all instruction about creation of package
                                    </p>
                                </div>
                            </div>
                        </div>
                                             
                    </div>
                    <!-- Form Row End Here -->

                </div>
                <!-- End container-fluid-->
            </div>
        <!--End content-wrapper-->

        <!--Start Back To Top Button-->
            <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
        <!--End Back To Top Button-->

        <!--Start footer-->
        <?php include 'layout/footer.php'; ?>
        <!--End footer-->

    </div>
    <!--End wrapper-->
    <?php include 'layout/footer_scripts.php'; ?>
    <script src="<?php echo base_url('assets/plugins/bootstrap-switch/bootstrap-switch.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/slim_img_uploader/slim.kickstart.min.js'); ?>"></script>
    <script>
        $(".bt-switch input[type='checkbox'], .bt-switch input[type='radio']").bootstrapSwitch();
        function uploaded(error, data, response) {
            $('#uploaded_file_name').val(response['file']);
            $('#current_img_type').val("NEW");
            notie.alert(1, 'Image Uploaded Successfully!', 2);
        }
        $('#next_date').datepicker({
            autoclose: true,
            todayHighlight: true,
            format: 'dd/mm/yyyy'
        });
    </script>
</body>

</html>