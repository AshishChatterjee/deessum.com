<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Question - <?php echo $project_head; ?></title>
    <!--favicon-->
    <link rel="icon" href="<?php echo base_url('assets/logo/favicon.png'); ?> " type="image/x-icon">
    <?php include 'layout/header_links.php'; ?>
    <!--Switchery-->
    <link href="<?php echo base_url('assets/plugins/bootstrap-switch/bootstrap-switch.min.css'); ?>" rel="stylesheet">
    <?php include 'layout/link_and_script_of_summernote.php'; ?>
    <link rel="stylesheet" href="<?php echo base_url('assets/slim_img_uploader/slim.min.css'); ?>">
</head>

<body>

    <!-- Start wrapper-->
    <div id="wrapper">
        <!--Start sidebar-wrapper-->
            <?php include 'layout/left_side_navigation.php' ?>
        <!--Start sidebar-wrapper-->

        <!--Start topbar header-->
            <?php include 'layout/header.php'; ?>
        <!--End topbar header-->

        <div class="clearfix"></div>

        <!--Start content-wrapper-->
            <div class="content-wrapper" >
                <div class="container-fluid" style="min-height:500px;" >

                    <!-- Breadcrumb-->
                    <div class="row pt-2 pb-2">
                        
                        <div class="col-sm-12">
                            <div class="">
                                <a href="<?php echo base_url('question/questionList/'); ?>" >
                                    <button class="btn-outline-success border-0 shadow-light m-1 pull-right"> <span class="moon-security-on"></span> Question List</button>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- End Breadcrumb-->

                    <!-- Form Row Start Here -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body bg-light-blue" >
                                    <div class="row pt-2 pb-2">
                                        <div class="col-sm">
                                            <h4>First round question</h4>
                                        </div>
                                    </div>
                                    <hr/>
                                    <form method="post" id="service_form" action="<?php echo base_url('question/question/') ?>">
                                        <input type="hidden" name="mode" id="mode" value="<?php if(isset($mode)){echo $mode; }else { echo set_value("mode"); } ?>" />
                                        <input type="hidden" name="id" id="id" value="<?php if(isset($question->id)){echo $question->id; }else { echo set_value("id"); } ?>" />

                                            <div class="row">

                                                <div class="col-md-12">
                                                    <div class="row">
                                                        <!-- Start : Question  -->
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label for="question">Question <span class="icon-star-empty text-danger"></span></label>
                                                                <input name="question" id="question" type="text" class="form-control" placeholder="Question" value="<?php if(isset($question->question)){echo $question->question; }else{echo set_value("question");} ?>">
                                                                <?php if(form_error("question")!=null){ echo form_error("question"); } ?>
                                                            </div>
                                                        </div>
                                                        <!-- End : Question -->

                                                        <!-- Start : Option 1  -->
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <label for="option1">Option 1 <span class="icon-star-empty text-danger"></span></label>
                                                                <input name="option1" id="option1" type="text" class="form-control" placeholder="Option 1" value="<?php if(isset($question->option1)){echo $question->option1; }else{echo set_value("option1");} ?>">
                                                                <?php if(form_error("option1")!=null){ echo form_error("option1"); } ?>
                                                            </div>
                                                        </div>
                                                        <!-- End : Option 1 -->

                                                        <!-- Start : Option 2  -->
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <label for="option2">Option 2 <span class="icon-star-empty text-danger"></span></label>
                                                                <input name="option2" id="option2" type="text" class="form-control" placeholder="Option 2" value="<?php if(isset($question->option2)){echo $question->option2; }else{echo set_value("option2");} ?>">
                                                                <?php if(form_error("option2")!=null){ echo form_error("option2"); } ?>
                                                            </div>
                                                        </div>
                                                        <!-- End : Option 2 -->

                                                        <!-- Start : Option 3  -->
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <label for="option3">Option 3 <span class="icon-star-empty text-danger"></span></label>
                                                                <input name="option3" id="option3" type="text" class="form-control" placeholder="Option 3" value="<?php if(isset($question->option3)){echo $question->option3; }else{echo set_value("option3");} ?>">
                                                                <?php if(form_error("option3")!=null){ echo form_error("option3"); } ?>
                                                            </div>
                                                        </div>
                                                        <!-- End : Option 3 -->

                                                        <!-- Start : Option 4  -->
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <label for="option4">Option 4 <span class="icon-star-empty text-danger"></span></label>
                                                                <input name="option4" id="option4" type="text" class="form-control" placeholder="Option 4" value="<?php if(isset($question->option4)){echo $question->option4; }else{echo set_value("option4");} ?>">
                                                                <?php if(form_error("option4")!=null){ echo form_error("option4"); } ?>
                                                            </div>
                                                        </div>
                                                        <!-- End : Option 4 -->

                                                        <!-- Start : Ans  -->
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <label for="ans">Ans <span class="icon-star-empty text-danger"></span></label>
                                                                <input name="ans" id="ans" type="text" class="form-control" placeholder="Answer " value="<?php if(isset($question->ans)){echo $question->ans; }else{echo set_value("ans");} ?>">
                                                                <?php if(form_error("ans")!=null){ echo form_error("ans"); } ?>
                                                            </div>
                                                        </div>
                                                        <!-- End : Ans -->

                                                        <!-- Start : Round -->
                                                        <div class="col-sm-3">
                                                            <div class="form-group">
                                                                <label for="round">Round</label>
                                                                <select name="round" id="round" class="form-control single-select">
                                                                    <option value="">--Select--</option>
                                                                    <option value="ROUND2" <?php if(isset($question->round) && $question->round=="ROUND2"){ echo "selected"; }else{ echo set_select("round","ROUND2"); } ?> >ROUND2</option>
                                                                    <option value="ROUND1" <?php if(isset($question->round) && $question->round=="ROUND1"){ echo "selected"; }else{ echo set_select("round","ROUND1"); } ?> >ROUND1</option>
                                                                </select>
                                                                <?php if(form_error("round")!=null){ echo form_error("round"); } ?>
                                                            </div>
                                                        </div>
                                                        <!-- End : Round -->


                                                    </div>
                                                </div>

                                                <div class="col-sm-12">
                                                    <button type="submit" class="btn btn-outline-success border-0 shadow-light m-1 pull-right"><span class="zmdi zmdi-check-all"></span> Submit</button>
                                                </div>
                                                <!-- End : Address -->
                                            </div>
                                        <br>
                                        <?php 
                                            $msg=$this->session->flashdata('message');
                                            if(isset($msg)){
                                                ?><br/><br/><p style="color:green;" class="pull-right"><?php echo $msg; ?></p><?php
                                            }
                                        ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Form Row End Here -->

                </div>
                <!-- End container-fluid-->
            </div>
        <!--End content-wrapper-->

        <!--Start Back To Top Button-->
            <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
        <!--End Back To Top Button-->

        <!--Start footer-->
        <?php include 'layout/footer.php'; ?>
        <!--End footer-->

    </div>
    <!--End wrapper-->
    <?php include 'layout/footer_scripts.php'; ?>
    <!--Bootstrap Switch Buttons-->
    <script src="<?php echo base_url('assets/plugins/bootstrap-switch/bootstrap-switch.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/plugins/summernote/dist/summernote-lite.js'); ?>"></script>
    <script src="<?php echo base_url('assets/slim_img_uploader/slim.kickstart.min.js'); ?>"></script>
    <script>
        $('#reciving_date').datepicker({
            autoclose: true,
            todayHighlight: true,
            format: 'dd/mm/yyyy'
        });
        $(document).ready(function() {
            $('.single-select').select2();

            $('.multiple-select').select2();
        });
        function submitForm() {
            $("#service_form").attr('action', "<?php echo base_url('services/getServicesOfSelectedCategory/');  ?>");
            $("#service_form").submit();
        }
        function deleteService(){
            alert("Deletion module is in waiting list");
            return false;
        }
        $(".bt-switch input[type='checkbox'], .bt-switch input[type='radio']").bootstrapSwitch();
        $('#description').summernote({
            height: 200,
            tabsize: 2,
            codemirror: { // codemirror options
                theme: 'monokai'
            }
        });

        function uploaded(error, data, response) {
            $('#uploaded_file_name').val(response['file']);
            $('#current_img_type').val("NEW");
            notie.alert(1, 'Image Uploaded Successfully!', 2);
        }

        $('#joining_date').datepicker({
            autoclose: true,
            todayHighlight: true,
            format: 'dd/mm/yyyy'
        });
    </script>
</body>

</html>